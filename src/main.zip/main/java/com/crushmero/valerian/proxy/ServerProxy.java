package com.crushmero.valerian.proxy;

public class ServerProxy {

}
